function toggleMenu() {
    var menu =
    document.getElementById("flyoutMenu");
    menu.classList.toggle("hidden");
        }
function closeMenu() {
    const flyoutMenu =
    document.getElementById('flyoutMenu');
    flyoutMenu.classList.add('hidden');
}